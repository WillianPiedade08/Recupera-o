const con = require('../connect/connect').con;

const create = (req, res) => {
    let telefone_id = req.body.clientes;
    let cliente_id = req.body.nome;
    let numero  = req.body.cpf;
    let tipo = req.body.tipo;
   
    let query = INSERT `INTO telefone (cliente_id, numero, tipo) VALUES`
    query += `('${telefone_id}', '${cliente_id}', '${numero}', '${tipo}');`;
    con.query(query, (err, result) => {
        if (err) {
            res.status(500).json(err)
        } else {   
            res.status(201).json(result)
        }
    })
}

const read = (req, res) => {
    con.query('SELECT * FROM telefone', (err, result) => {
        if (err) {
            res.status(500).json(err)
        } else {
            res.json(result)
        }
    })
}

module.exports = {
    create,
    read
}